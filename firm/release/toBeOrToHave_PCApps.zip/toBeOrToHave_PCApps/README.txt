############### README EN ###############
@Author : Simon SERRANO, Pierre RAINERO
@Contact : http://pierre-rainero.fr/
@Release : 14/03/2017 - https://github.com/PierreRainero/ihmproject2017/releases 
@Copyright : You can use the source code and modify it if you want. Just dont use it for commercial purposes (quoting us is optional). - CC (Creative Commons)

This project was created within the lesson of the "HCI" at the Polytech'Nice school during the school year 2016-2017 (3rd year of computer science engineering).

############### LISEZ-MOI FR ###############
@Auteur : Simon SERRANO, Pierre RAINERO
@Contact : http://pierre-rainero.fr/
@Version : 14/03/2017 - https://github.com/PierreRainero/ihmproject2017/releases 
@Licence : Vous pouvez utiliser ce code ou le modifier sans problème. Merci de ne pas le faire à des fins commerciales (vous pouvez nous citer en tant que source mais cela reste facultatif). - CC (Creative Commons)

Ce projet a été créé durant le cours "IHM" de l'école Polytech'Nice durant l'année scolaire 2016-2017 (3ième année de sciences informatiques du cycle ingénieur).